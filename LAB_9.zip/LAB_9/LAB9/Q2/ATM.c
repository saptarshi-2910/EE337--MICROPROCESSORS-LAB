#include <at89c5131.h>
#include "lcd.h"		// Header file with LCD interfacing functions
#include "serial.h"	// Header file with UART interfacing functions
#include <stdlib.h>

sbit LED1=P1^7;
sbit LED2=P1^6;
sbit LED3=P1^5;
sbit LED4=P1^4;

int balance_Acct1=10000;
int balance_Acct2=10000;
char Account1[6]="Steven";
char Account2[6]="Gordon";
char Pass1[5]="EE337";
char Pass2[5]="UPLAB";
char str1[2]="";
int amount_demanded=0;
int n5=0;
int n1=0;
unsigned char temp[5]=0;

// Test function definitions
/****************
lcd_test():
	LCD test function that gets called when
	'1' is received from UART
	Prints "LCD Ok" on LCD. After 4 seconds
	LCD is cleared
****************/
void lcd_test(void)
{
	 lcd_cmd(0x80);
	 lcd_write_string("LCD Ok");
	 msdelay(4000);    //clearing the screen after 4s
	 lcd_cmd(0x01);
	 transmit_string("LCD tested\r\n");
	 msdelay(200);
}	

/****************
led_test():
	LED test code. Update this function
	to test LEDs on P1.7-P1.4 by blinking
	them for a few times.
****************/
void led_test(void)
{
	// Write your testing code here.	
	int i=0;
	for(i=0;i<3;i++)
	{
		LED1=1;
		LED2=1;
		LED3=1;
		LED4=1;
		msdelay(500);
		LED1=0;
		LED2=0;
		LED3=0;
		LED4=0;
	}
	transmit_string("LED tested\r\n");	
	msdelay(200);
}

// Main function
void main(void)
{
	unsigned char ch=0;
	
	// Initialize port P1 for output from P1.7-P1.4
	P1 = 0x0F;
	
	// Call initialization functions
	lcd_init();
	uart_init();
	
	// These strings will be printed in terminal software
	transmit_string("Press A for Account display and W for withdrwaing cash \r\n");
	
	
	while(1)
	{
		  
			// Receive a character
		  transmit_string("Press A for Account display and W for withdrwaing cash \r\n");
			ch = receive_char();
		
			// Decide which test function to run based on character sent
     		// Displays the string on the terminal software
			switch(ch)
			{
				case 'a':
				case 'A':
					transmit_string("Hello, Please enter Account Number");
				  ch=receive_char();
				  if(ch=='1')
					{		  
						transmit_string("Acoount Holder: Steven\r\n");
						transmit_string("Balance:");
						int_to_string(balance_Acct1,temp);
						transmit_string(temp);
						transmit_string("\r\n");						
					}
					else if(ch=='2')
					{
						transmit_string("Acoount Holder: Gordon\r\n");
						transmit_string("Balance:");
						int_to_string(balance_Acct2,temp);
						transmit_string(temp);
						transmit_string("\r\n");
					}
					else
					{
						transmit_string("No such account, please enter valid details");
					}
					break;
					
				case 'w':
				case 'W':
					transmit_string("Withdraw state, enter account number");
				  ch=receive_char();
				  if(ch=='1')
					{
						transmit_string("Acoount Holder: Steven\r\n");
						transmit_string("Balance:");
						int_to_string(balance_Acct1,temp);
						transmit_string(temp);
						transmit_string("\r\n");
						transmit_string("Enter Amount, in hundreds");
						ch=receive_char();
						str1[0]=ch;
						ch=receive_char();						
						str1[1]=ch;
						amount_demanded=atoi(str1)*100;
            if(amount_demanded==0)
						{
							transmit_string("Invalid Amount");
            }
            else{
							if(balance_Acct1>=amount_demanded)
							{
								balance_Acct1=balance_Acct1-amount_demanded;
								n5=amount_demanded/500;
								n1=(amount_demanded%500)/100;
								transmit_string("Remaining Balance:");
                int_to_string(balance_Acct1,temp);
					      transmit_string(temp);
								transmit_string("\r\n");
								transmit_string("500 Notes:");
								int_to_string(n5,temp);
						    transmit_string(temp);
								transmit_string(", 100 Notes:");
								int_to_string(n1,temp);
						    transmit_string(temp);
								transmit_string("\r\n");								
							}
							else
							{
								transmit_string("Insufficient Funds");
							}
															
						}							
            						
					}
					else if(ch=='2')
					{
						transmit_string("Acoount Holder: Gordon\r\n");
						transmit_string("Balance:");
						int_to_string(balance_Acct2,temp);
					  transmit_string(temp);
						transmit_string("\r\n");
						transmit_string("Enter Amount, in hundreds");
						ch=receive_char();
						str1[0]=ch;
						ch=receive_char();						
						str1[1]=ch;
						amount_demanded=atoi(str1)*100;
            if(amount_demanded==0)
						{
							transmit_string("Invalid Amount");
							break;
						}
            
            else{
							if(balance_Acct2>=amount_demanded)
							{
								balance_Acct2=balance_Acct2-amount_demanded;
								n5=amount_demanded/500;
								n1=(amount_demanded%500)/100;
								transmit_string("Remaining Balance:");
                int_to_string(balance_Acct2,temp);
					      transmit_string(temp);
								transmit_string("\r\n");
								transmit_string("500 Notes:");
								int_to_string(n5,temp);
					      transmit_string(temp);
								transmit_string(", 100 Notes:");
								int_to_string(n1,temp);
					      transmit_string(temp);
								transmit_string("\r\n");								
							}
							else
							{
								transmit_string("Insufficient Funds");
							}								
						}							
					}
					else
						transmit_string("No such account, please enter valid details");							
					break;
					
					default:
					transmit_string("Incorrect key pressed");
				  msdelay(200);
					break;
			}
			msdelay(100);
	}
}