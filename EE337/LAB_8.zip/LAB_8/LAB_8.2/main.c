/**********************************************************
EE337: ADC IC MCP3008 interfacing with pt-51
(1) Complete spi_init() function from spi.h 

***********************************************************/

#include <at89c5131.h>
#include "lcd.h"																				//Driver for interfacing lcd 
#include "mcp3008.h"																		//Driver for interfacing ADC ic MCP3008


char adc_ip_data_ascii1[6]={0,0,0,0,0,'\0'};							//string array for saving ascii of input sample
char adc_ip_data_ascii2[6]={0,0,0,0,0,'\0'};
code unsigned char display_msg1[]="Volt.: ";						//Display msg on 1st line of lcd
code unsigned char display_msg2[]=" mV";								//Display msg on 2nd line of lcd
code unsigned char display_msg3[]="Temp.:";
code unsigned char display_msg4[]=" oC";


void main(void)
	

{
	int j=0;
	unsigned int adc_data1=0;
	unsigned int adc_data2=0;
	
	spi_init();																					
	adc_init();
  lcd_init();
	
	
	
	while(1)
	{
	 	unsigned int x;
		unsigned int y;
		
		 
		x = adc(4);																					//Read analog value from 4th channel of ADC Ic MCP3008
		y=adc(3);
		adc_data1 = (unsigned int) (x*3.2258); 							//Converting received 10 bits value to milli volt (3.3*1000*i/p /1023)
    adc_data2=   (unsigned int) (y*322.58);
		/*
		    Display "Volt: " on first line of lcd
		    Print analog sampled input on lcd using int_to_string function and 
		    Display "XXXXX mV" on second line of LCD
		
		*/
		 lcd_cmd(0x01);
		lcd_cmd(0x80); // Set cursor to the beginning of the first line
    lcd_write_string(display_msg1);
		int_to_string(adc_data1, adc_ip_data_ascii1);
    lcd_write_string(adc_ip_data_ascii1);
		lcd_write_string(display_msg2);
		msdelay(1000);	
		lcd_cmd(0xC0); // Set cursor to the beginning of the second line
    lcd_write_string(display_msg3);
		int_to_string(adc_data2,adc_ip_data_ascii2);
		lcd_write_string(adc_ip_data_ascii2);
    lcd_write_string(display_msg4);
		msdelay(2000);
	}
}