#include <at89c5131.h>
#include "lcd.h"
#include <math.h>
signed int w0=-36;
signed int w1=5;
signed int w2=7;
signed int y;
signed int x1;
signed int x2;
float z;
code unsigned char display_msg1[]="      Input1:     ";						//Display msg on 1st line of lcd
code unsigned char display_msg2[]="      Input2:     ";	
code unsigned char display_msg3[]="      Prediction:     ";						//Display msg on 1st line of lcd
code unsigned char display_msg4[]="P(Class 2):";
code unsigned char display_msg5[]="P(Class 1):";	//Display msg on 1st line of lcd

void main()
{
	lcd_init();
	lcd_cmd(0x80);
	lcd_write_string(display_msg1);
	P1=0x0F;
	msdelay(5000);
	x1=P1;
	lcd_cmd(0x80);
	lcd_write_string(display_msg2);
	P1=0x0F;
	msdelay(5000);
	x2=P1;
	y=w0+x1*w1+x2*w2;
	z=1/(1+pow(2.718,-y));
	lcd_init();
	lcd_cmd(0xC0);
	lcd_write_string(display_msg4);
	lcd_float(z);
	lcd_cmd(0X80);
	lcd_write_string(display_msg5);
	lcd_float(1-z);	
	while(1);
		
}